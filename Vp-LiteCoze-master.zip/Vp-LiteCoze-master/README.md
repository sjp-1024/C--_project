V-play LiteCoze项目说明（界面说明）

1. 新增修改主题颜色按钮，使用自己喜欢的风格

2. 虽然程序是以聊天室为主，但作为聊天软件，除了聊天之外，说说自己的心情、动态也很重要，所以新增说说功能，目前只实现了发表文字，不能发表图片和视频

3. 修改主题颜色因为list子项实现不同功能没有找到解决方法，所以暂时用按钮实现，以后以此为目标改进

4. 修改之前原定为聊天的页面为关注页面

实现：古长蓉


V-play LiteCoze项目说明（后台服务）

1. 收发客户端的实现

2. 将用户发表的说说存储到数据库中，并显示在屏幕上


实现：杜虹朋

![](https://github.com/qt-se1606/Vp-LiteCoze/blob/master/1.png)

![](https://github.com/qt-se1606/Vp-LiteCoze/blob/master/2.png)

![](https://github.com/qt-se1606/Vp-LiteCoze/blob/master/3.png)
