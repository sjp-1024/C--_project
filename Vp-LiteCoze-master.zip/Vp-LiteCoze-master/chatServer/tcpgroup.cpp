#include "tcpgroup.h"

TcpGroup::TcpGroup(QString id, QString name):m_id(id), m_name(name)
{

}
