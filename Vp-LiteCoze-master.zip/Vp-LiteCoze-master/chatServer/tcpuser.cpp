#include "tcpuser.h"

TcpUser::TcpUser(QString name, QString powerpoint):m_name(name), m_powerpoint(powerpoint)
{

}
