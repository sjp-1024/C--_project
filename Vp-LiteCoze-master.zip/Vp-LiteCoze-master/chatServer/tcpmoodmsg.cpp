#include "tcpmoodmsg.h"

TcpMoodMsg::TcpMoodMsg(QString username, QString msg):m_username(username), m_msg(msg)
{

}
