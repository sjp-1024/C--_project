﻿#include <QtCore>
#include <QtGui>
#include <QtNetwork>

#if (QT_VERSION > QT_VERSION_CHECK(5,0,0))
#include <QtWidgets>
#endif

#include "app.h"

#pragma execution_character_set("utf-8")
