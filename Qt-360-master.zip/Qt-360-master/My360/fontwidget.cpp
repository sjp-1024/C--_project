#include "fontwidget.h"

FontWidget::FontWidget(QWidget *parent) :
    QWidget(parent)
{
}
