#ifndef _DIAL_TAB_H
#define _DIAL_TAB_H 1

#include <qwidget.h>

class DialTab: public QWidget
{
public:
    DialTab( QWidget *parent = NULL );
};

#endif
